package com.docmall.dto;

import lombok.Data;

@Data
public class LoginDTO {
	
	private String mbr_id; //아이디
	private String mbr_pw; //비밀번호

}
