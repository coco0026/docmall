package com.docmall.service;

public interface AdminMenuService {

}
