package com.docmall.service;

public interface CommonCodeService {

}
