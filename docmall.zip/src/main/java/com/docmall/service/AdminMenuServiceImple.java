package com.docmall.service;

import org.springframework.stereotype.Service;

@Service
public class AdminMenuServiceImple implements AdminMenuService {

}
