package com.docmall.mapper;

public interface AdminMenuMapper {

}
